import { 
    Client, 
    GatewayIntentBits, 
    Events, 
    ChannelType, 
    PermissionFlagsBits, 
    Collection, 
    REST, 
    Routes,
    TextChannel,
    EmbedBuilder 
} from 'discord.js';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';
import { prisma } from './db';
import { checkSocialAlerts } from './utils/SocialManager';

dotenv.config();

// Extension of the Client interface
declare module 'discord.js' {
  export interface Client {
    commands: Collection<string, any>;
  }
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers, 
    GatewayIntentBits.GuildVoiceStates, // Added for Temp Channels
  ],
});

client.commands = new Collection();

// =====================================================
// 1. COMMAND LOADER (HANDLER)
// =====================================================
async function loadCommands() {
  const commandsPath = path.join(__dirname, 'commands');
  
  if (!fs.existsSync(commandsPath)) {
      console.log("📂 Creating 'commands' folder...");
      fs.mkdirSync(commandsPath);
      ['General', 'Tickets', 'Moderation', 'Economy', 'RP', 'Company', 'Configuration', 'Utils'].forEach(dir => {
          fs.mkdirSync(path.join(commandsPath, dir));
      });
  }

  const commandFolders = fs.readdirSync(commandsPath);
  const commandsToRegister = [];

  for (const folder of commandFolders) {
    const folderPath = path.join(commandsPath, folder);
    if (fs.statSync(folderPath).isDirectory()) {
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.ts') || file.endsWith('.js'));
        
        for (const file of commandFiles) {
            const filePath = path.join(folderPath, file);
            const command = require(filePath); 
            
            if ('data' in command && 'execute' in command) {
                client.commands.set(command.data.name, command);
                commandsToRegister.push(command.data.toJSON());
                console.log(`🔹 Command loaded : ${command.data.name}`);
            } else {
                console.warn(`⚠️ Command at ${filePath} missing "data" or "execute".`);
            }
        }
    }
  }

  const rest = new REST().setToken(process.env.DISCORD_TOKEN!);
  try {
      console.log(`⏳ Registering ${commandsToRegister.length} commands...`);
      await rest.put(
          Routes.applicationCommands(process.env.DISCORD_CLIENT_ID!),
          { body: commandsToRegister },
      );
      console.log(`✅ Commands registered successfully!`);
  } catch (error) {
      console.error(error);
  }
}

// =====================================================
// 2. EVENT LOADER (HANDLER)
// =====================================================
function loadEvents() {
    const eventsPath = path.join(__dirname, 'events');
    if (fs.existsSync(eventsPath)) {
        const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.ts') || file.endsWith('.js'));
        for (const file of eventFiles) {
            const filePath = path.join(eventsPath, file);
            const event = require(filePath);
            if (event.once) {
                client.once(event.name, (...args) => event.execute(...args));
            } else {
                client.on(event.name, (...args) => event.execute(...args));
            }
            console.log(`🔹 Event loaded : ${event.name}`);
        }
    }
}

// =====================================================
// 3. INITIALIZATION & SYNCHRONIZATION
// =====================================================
client.once(Events.ClientReady, async (c) => {
  console.log(`✅ ${c.user.tag} is online!`);
  await loadCommands();
  loadEvents(); // Load events like messageCreate, voiceStateUpdate

  // Sync Guilds
  for (const guild of c.guilds.cache.values()) {
    // 1. Sync Table Guild
    await prisma.guild.upsert({
      where: { id: guild.id },
      update: { name: guild.name, icon: guild.iconURL(), ownerId: guild.ownerId },
      create: { id: guild.id, name: guild.name, icon: guild.iconURL(), ownerId: guild.ownerId }
    });

    // 2. Init Table GuildConfig (for Dashboard)
    const configExists = await prisma.guildConfig.findUnique({ where: { guildId: guild.id }});
    if (!configExists) {
        await prisma.guildConfig.create({ data: { guildId: guild.id }});
    }

    console.log(`📥 Server synced : ${guild.name}`);
  }
  console.log("💾 Database up to date!");

  // Start Social Media Check Loop (Every 5 minutes)
  setInterval(() => {
      checkSocialAlerts(client);
  }, 5 * 60 * 1000);
});

// New Guilds Joined
client.on(Events.GuildCreate, async (guild) => {
  await prisma.guild.create({
    data: { id: guild.id, name: guild.name, icon: guild.iconURL(), ownerId: guild.ownerId }
  });
  await prisma.guildConfig.create({ data: { guildId: guild.id }});
  console.log(`🎉 Joined new server : ${guild.name}`);
});

// =====================================================
// 4. INTERACTION MANAGEMENT (Commands & Buttons)
// =====================================================
client.on(Events.InteractionCreate, async interaction => {
    const { guildId } = interaction;
    if (!guildId || !interaction.guild) return;

    // -----------------------------------------------------
    // A. SLASH COMMANDS (With Dashboard Config)
    // -----------------------------------------------------
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        try {
            // 1. Check Server Config (Enabled/Disabled & Roles)
            const config = await prisma.guildConfig.findUnique({ where: { guildId } });
            
            if (config) {
                // Check Disabled
                if (config.disabledCommands.includes(interaction.commandName)) {
                    return interaction.reply({ content: "❌ This command is disabled on this server.", ephemeral: true });
                }

                // Check Required Roles (RBAC)
                const allowedRoles = (config.commandRoles as any)?.[interaction.commandName];
                if (allowedRoles && allowedRoles.length > 0) {
                    const memberRoles = (interaction.member?.roles as any).cache;
                    const hasRole = memberRoles.some((r: any) => allowedRoles.includes(r.id));
                    
                    if (!hasRole && !(interaction.member?.permissions as any).has(PermissionFlagsBits.Administrator)) {
                        return interaction.reply({ content: "⛔ You do not have the required role to use this command.", ephemeral: true });
                    }
                }
            }

            // 2. Execution
            await command.execute(interaction);

        } catch (error) {
            console.error(error);
            const resp = { content: '❌ Internal error executing command.', ephemeral: true };
            if (interaction.replied || interaction.deferred) await interaction.followUp(resp);
            else await interaction.reply(resp);
        }
    }

    // -----------------------------------------------------
    // B. BUTTON MANAGEMENT (Tickets & Reaction Roles)
    // -----------------------------------------------------
    if (interaction.isButton()) {
        
        // --- 1. TICKET OPENING ---
        if (interaction.customId.startsWith('open_ticket_')) {
            await interaction.deferReply({ ephemeral: true });
            const panelId = interaction.customId.replace('open_ticket_', '');

            try {
                const panel = await prisma.ticketPanel.findUnique({ where: { id: panelId } });
                if (!panel) return interaction.editReply("❌ This ticket panel no longer exists.");

                // Channel Name (ex: ticket-username)
                const channelName = panel.namingScheme.replace('{username}', interaction.user.username).replace('{id}', interaction.user.id);
                
                // Create Channel
                const ticketChannel = await interaction.guild.channels.create({
                    name: channelName,
                    type: ChannelType.GuildText,
                    parent: panel.targetCategory || null,
                    permissionOverwrites: [
                        { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
                        { id: client.user!.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
                        // Add configured Staff roles
                        ...(panel.mentionRoles.map(roleId => ({
                            id: roleId,
                            allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] as bigint[]
                        })))
                    ]
                });

                // Save User to DB
                const dbUser = await prisma.user.upsert({
                    where: { discordId: interaction.user.id },
                    create: { discordId: interaction.user.id, username: interaction.user.username },
                    update: { username: interaction.user.username }
                });

                // Create Ticket in DB
                let category = await prisma.ticketCategory.findFirst({ where: { guildId } }); 
                if(!category) category = await prisma.ticketCategory.create({ data: { name: "Default", guildId }});

                await prisma.ticket.create({
                    data: {
                        guildId,
                        channelId: ticketChannel.id,
                        creatorId: dbUser.id,
                        categoryId: category.id,
                        status: "OPEN"
                    }
                });

                // Welcome Message
                const welcomeEmbed = new EmbedBuilder()
                    .setTitle(`Ticket : ${interaction.user.username}`)
                    .setDescription(`Welcome ${interaction.user}.\nA staff member will be with you shortly.`)
                    .setColor(0x5865F2);

                await ticketChannel.send({ 
                    content: panel.mentionRoles.map(r => `<@&${r}>`).join(' '), 
                    embeds: [welcomeEmbed] 
                });

                await interaction.editReply(`✅ Ticket created: ${ticketChannel}`);

            } catch (err) {
                console.error(err);
                await interaction.editReply("❌ Error creating ticket.");
            }
        }

        // --- 2. REACTION ROLES (Via Buttons) ---
        if (interaction.customId.startsWith('reaction_role_')) {
            const reactionId = interaction.customId.replace('reaction_role_', '');
            
            try {
                const reactionConfig = await prisma.reactionRole.findUnique({ 
                    where: { id: reactionId },
                    include: { panel: true } 
                });

                if (!reactionConfig) return interaction.reply({ content: "❌ Configuration not found.", ephemeral: true });

                const roleId = reactionConfig.roleId;
                const member = interaction.member as any; 

                if (member.roles.cache.has(roleId)) {
                    await member.roles.remove(roleId);
                    await interaction.reply({ content: `➖ Role <@&${roleId}> removed.`, ephemeral: true });
                } else {
                    await member.roles.add(roleId);
                    await interaction.reply({ content: `➕ Role <@&${roleId}> added!`, ephemeral: true });
                }

            } catch (err) {
                console.error(err);
                await interaction.reply({ content: "❌ Error (Missing permissions?)", ephemeral: true });
            }
        }
    }
});

client.login(process.env.DISCORD_TOKEN);