// apps/bot/src/db.ts
import { PrismaClient } from '@prisma/client';

// On utilise une instance globale pour éviter de multiplier les connexions en dev
const globalForPrisma = global as unknown as { prisma: PrismaClient };

export const prisma =
  globalForPrisma.prisma ||
  new PrismaClient({
    log: ['query'],
  });

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma;