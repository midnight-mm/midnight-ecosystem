import { Events, EmbedBuilder } from 'discord.js';
import { prisma } from '../db';

module.exports = {
    name: Events.MessageCreate,
    async execute(message: any) {
        if (message.author.bot || !message.guild) return;

        // --- 1. NOTIFICATION MP SI RÔLE PING (Capture 1 & Custom) ---
        if (message.mentions.roles.size > 0) {
            const mentionedRoleIds = message.mentions.roles.map((r: any) => r.id);
            
            // Chercher si une config existe pour ces rôles
            const configs = await prisma.customMessage.findMany({
                where: { 
                    guildId: message.guild.id, 
                    type: 'DM_NOTIFICATION',
                    targetId: { in: mentionedRoleIds },
                    isActive: true
                }
            });

            for (const config of configs) {
                // On envoie un MP à tous les membres du rôle (Attention Rate Limits !)
                const role = message.guild.roles.cache.get(config.targetId);
                if (role) {
                    role.members.forEach(async (member: any) => {
                        try {
                            const embed = new EmbedBuilder(config.embed as any);
                            await member.send({ content: `Vous avez été mentionné sur **${message.guild.name}**`, embeds: [embed] });
                        } catch (e) { /* MP fermés */ }
                    });
                }
            }
        }

        // --- 2. IA (MEE6-like) ---
        // Vérifier si le salon est activé pour l'IA
        const aiConfig = await prisma.aIConfig.findUnique({ where: { guildId: message.guild.id } });
        if (aiConfig && aiConfig.isActive && aiConfig.channels.includes(message.channel.id)) {
            // Appeler API OpenAI ici
            // const reponse = await openai.chat.completions.create(...)
            // message.reply(reponse);
        }
    }
};