import { Events, ChannelType, PermissionFlagsBits } from 'discord.js';
import { prisma } from '../db';

// Mémoire temporaire pour suivre les salons créés
const tempChannels = new Set<string>();

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState: any, newState: any) {
        const guildId = newState.guild.id;
        const member = newState.member;

        // 1. REJOINDRE : Création de salon
        if (newState.channelId) {
            const config = await prisma.tempChannelConfig.findFirst({
                where: { guildId, triggerChannelId: newState.channelId }
            });

            if (config) {
                const guild = newState.guild;
                const channelName = config.channelName.replace('{user}', member.user.username);

                const newChannel = await guild.channels.create({
                    name: channelName,
                    type: ChannelType.GuildVoice,
                    parent: config.categoryId,
                    permissionOverwrites: [
                        { id: member.id, allow: [PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MoveMembers] }
                    ]
                });

                await member.voice.setChannel(newChannel);
                tempChannels.add(newChannel.id);
            }
        }

        // 2. QUITTER : Suppression si vide
        if (oldState.channelId && tempChannels.has(oldState.channelId)) {
            const channel = oldState.channel;
            if (channel && channel.members.size === 0) {
                await channel.delete();
                tempChannels.delete(oldState.channelId);
            }
        }
    }
};