import { REST, Routes, SlashCommandBuilder } from 'discord.js';
import dotenv from 'dotenv';

dotenv.config();

const token = process.env.DISCORD_TOKEN;
// Ton ID d'application
const clientId = "1459566940921266228"; 

const commands = [
  new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Vérifie si le bot est en ligne et donne la latence.'),
  new SlashCommandBuilder()
    .setName('info')
    .setDescription('Affiche les informations du serveur.'),
  // --- AJOUT DE LA COMMANDE TICKET ---
  new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Ouvre un ticket de support.'),
]
  .map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(token!);

(async () => {
  try {
    console.log('⏳ Début du rafraîchissement des commandes (/) ...');

    await rest.put(
      Routes.applicationCommands(clientId),
      { body: commands },
    );

    console.log('✅ Commandes (/) enregistrées avec succès !');
  } catch (error) {
    console.error(error);
  }
})();