import { EmbedBuilder, Client, TextChannel } from 'discord.js';
import { prisma } from '../db';

export async function sendLog(client: Client, guildId: string, type: 'mod' | 'ticket' | 'join' | 'eco', embed: EmbedBuilder) {
    try {
        // 1. Récupérer la config du serveur
        const guildData = await prisma.guild.findUnique({ where: { id: guildId } });
        if (!guildData || !guildData.config) return;

        const config = guildData.config as any;

        // 2. Vérifier si un salon est configuré pour ce type de log
        if (!config.logs || !config.logs[type]) return;

        const channelId = config.logs[type];
        const channel = await client.channels.fetch(channelId) as TextChannel;

        if (channel) {
            await channel.send({ embeds: [embed] });
        }
    } catch (error) {
        console.error(`Erreur Logger (${type}):`, error);
    }
}