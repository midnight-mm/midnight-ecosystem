// Fichier : apps/bot/src/utils/TicketSystem.ts

import { 
    Client, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    TextChannel 
} from 'discord.js';
import { prisma } from '../db';

/**
 * Cette fonction lit la configuration d'un panel dans la BDD
 * et le publie (ou le met à jour) dans le salon Discord.
 */
export async function syncTicketPanel(client: Client, panelId: string) {
    try {
        // 1. Récupérer la config du panel depuis la DB
        const panelConfig = await prisma.ticketPanel.findUnique({ where: { id: panelId } });
        
        if (!panelConfig) {
            console.log(`❌ Panel introuvable (ID: ${panelId})`);
            return;
        }

        if (!panelConfig.channelId) {
            console.log(`⚠️ Aucun salon configuré pour le panel "${panelConfig.title}"`);
            return;
        }

        // 2. Récupérer le salon Discord
        const channel = await client.channels.fetch(panelConfig.channelId) as TextChannel;
        if (!channel) {
            console.log(`❌ Salon introuvable (ID: ${panelConfig.channelId})`);
            return;
        }

        // 3. Construire l'Embed (Apparence)
        const embed = new EmbedBuilder()
            .setTitle(panelConfig.title)
            .setDescription(panelConfig.description)
            .setColor(panelConfig.color as any); // Le code hexa (ex: #5865F2)

        if (panelConfig.image) embed.setImage(panelConfig.image);
        if (panelConfig.thumbnail) embed.setThumbnail(panelConfig.thumbnail);
        if (panelConfig.footer) embed.setFooter({ text: panelConfig.footer });

        // 4. Construire le Bouton
        // On mappe le style (string) vers l'Enum Discord
        let style = ButtonStyle.Primary;
        switch (panelConfig.buttonStyle) {
            case 'SECONDARY': style = ButtonStyle.Secondary; break;
            case 'SUCCESS': style = ButtonStyle.Success; break;
            case 'DANGER': style = ButtonStyle.Danger; break;
            case 'LINK': style = ButtonStyle.Link; break;
        }

        const btn = new ButtonBuilder()
            .setCustomId(`open_ticket_${panelConfig.id}`) // ID unique pour l'interaction
            .setLabel(panelConfig.buttonLabel || "Ouvrir un ticket")
            .setStyle(style);

        if (panelConfig.buttonEmoji) {
            btn.setEmoji(panelConfig.buttonEmoji);
        }

        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(btn);

        // 5. Envoyer ou Mettre à jour le message
        // Si on a déjà un ID de message enregistré, on essaie de l'éditer
        if (panelConfig.messageId) {
            try {
                const msg = await channel.messages.fetch(panelConfig.messageId);
                await msg.edit({ embeds: [embed], components: [row] });
                console.log(`✅ Panel "${panelConfig.title}" mis à jour.`);
                return;
            } catch (e) { 
                console.log("⚠️ Le message du panel semble avoir été supprimé. Envoi d'un nouveau...");
                // Si erreur (ex: message supprimé manuellement), on continue pour en envoyer un nouveau
            }
        }

        // Sinon, on envoie un nouveau message
        const msg = await channel.send({ embeds: [embed], components: [row] });
        
        // 6. Sauvegarder l'ID du nouveau message en DB
        await prisma.ticketPanel.update({ 
            where: { id: panelId }, 
            data: { messageId: msg.id } 
        });
        
        console.log(`✅ Panel "${panelConfig.title}" publié avec succès.`);

    } catch (error) {
        console.error("❌ Erreur lors de la synchro du TicketPanel :", error);
    }
}