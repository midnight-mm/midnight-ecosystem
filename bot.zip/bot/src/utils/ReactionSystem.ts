// Fichier : apps/bot/src/utils/ReactionSystem.ts

import { 
    Client, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle, 
    TextChannel 
} from 'discord.js';
import { prisma } from '../db';

/**
 * Cette fonction synchronise un Panel de Rôles-Réactions (Embed + Boutons)
 * depuis la base de données vers le salon Discord.
 */
export async function syncReactionPanel(client: Client, panelId: string) {
    try {
        // 1. Récupérer la config du panel ET ses réactions associées
        const config = await prisma.reactionPanel.findUnique({ 
            where: { id: panelId },
            include: { 
                reactions: {
                    orderBy: { id: 'asc' } // On garde l'ordre de création
                } 
            }
        });

        if (!config) {
            console.log(`❌ ReactionPanel introuvable (ID: ${panelId})`);
            return;
        }

        // 2. Récupérer le salon
        const channel = await client.channels.fetch(config.channelId) as TextChannel;
        if (!channel) {
            console.log(`❌ Salon introuvable (ID: ${config.channelId})`);
            return;
        }

        // 3. Construire l'Embed
        const embed = new EmbedBuilder()
            .setTitle(config.title)
            .setDescription(config.description)
            .setColor(config.color as any);

        // 4. Construire les Boutons (Max 5 par ligne)
        const rows: ActionRowBuilder<ButtonBuilder>[] = [];
        let currentRow = new ActionRowBuilder<ButtonBuilder>();

        config.reactions.forEach((reaction, index) => {
            // Si on a déjà 5 boutons dans la ligne, on en crée une nouvelle
            if (index > 0 && index % 5 === 0) {
                rows.push(currentRow);
                currentRow = new ActionRowBuilder<ButtonBuilder>();
            }
            
            // Création du bouton pour le rôle
            const btn = new ButtonBuilder()
                .setCustomId(`reaction_role_${reaction.id}`) // ID unique pour l'interaction
                .setLabel(reaction.label || "Rôle")
                .setStyle(ButtonStyle.Secondary); // Gris par défaut

            // Ajout de l'emoji si présent
            if (reaction.emoji) {
                btn.setEmoji(reaction.emoji);
            }

            // (Optionnel) Changer la couleur si c'est un bouton "danger" ou "success"
            // Ici on peut personnaliser selon le type stocké en DB si besoin

            currentRow.addComponents(btn);
        });

        // Ne pas oublier d'ajouter la dernière ligne si elle n'est pas vide
        if (currentRow.components.length > 0) {
            rows.push(currentRow);
        }

        // 5. Envoyer ou Mettre à jour le message
        if (config.messageId) {
             try {
                const msg = await channel.messages.fetch(config.messageId);
                await msg.edit({ embeds: [embed], components: rows });
                console.log(`✅ ReactionPanel "${config.title}" mis à jour.`);
                return;
             } catch(e) {
                console.log("⚠️ Message introuvable, création d'un nouveau...");
             }
        }

        // Nouveau message
        const msg = await channel.send({ embeds: [embed], components: rows });
        
        // 6. Sauvegarder l'ID du message
        await prisma.reactionPanel.update({ 
            where: { id: panelId }, 
            data: { messageId: msg.id } 
        });
        
        console.log(`✅ ReactionPanel "${config.title}" publié.`);

    } catch (error) {
        console.error("❌ Erreur syncReactionPanel :", error);
    }
}