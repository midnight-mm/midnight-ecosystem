import { Client, TextChannel } from 'discord.js';
import { prisma } from '../db';

export async function checkSocialAlerts(client: Client) {
    // Récupérer toutes les alertes actives
    const alerts = await prisma.socialAlert.findMany({ where: { isActive: true } });

    for (const alert of alerts) {
        try {
            let newPost = null;

            // Logique de simulation (En prod, installez 'rss-parser' ou utilisez les API officielles)
            if (alert.platform === 'YOUTUBE') {
                // newPost = await YouTubeAPI.getLatestVideo(alert.channelId);
            } else if (alert.platform === 'TWITCH') {
                // newPost = await TwitchAPI.getStreamStatus(alert.username);
            }
            
            // Si nouveau contenu trouvé et différent du dernier enregistré
            if (newPost && newPost.id !== alert.lastPostId) {
                const channel = await client.channels.fetch(alert.targetChannelId) as TextChannel;
                if (channel) {
                    const msg = alert.message
                        .replace('{user}', alert.username)
                        .replace('{link}', newPost.url);
                    
                    await channel.send(msg);

                    // Mise à jour DB
                    await prisma.socialAlert.update({
                        where: { id: alert.id },
                        data: { lastPostId: newPost.id }
                    });
                }
            }
        } catch (e) {
            console.error(`Erreur Social Alert (${alert.platform}):`, e);
        }
    }
}