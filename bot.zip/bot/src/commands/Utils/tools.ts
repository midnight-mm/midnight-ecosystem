import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tools') // 👈 CORRECTION ICI (C'était 'utils' avant)
        .setDescription('Outils divers (Help, Poll, Userinfo...)')
        .addSubcommand(sub => sub.setName('help').setDescription('Liste des commandes'))
        .addSubcommand(sub => sub.setName('userinfo').setDescription('Infos compte')
             .addUserOption(op => op.setName('target').setDescription('Membre')))
        .addSubcommand(sub => sub.setName('serverinfo').setDescription('Infos serveur'))
        .addSubcommand(sub => 
            sub.setName('poll').setDescription('Créer un sondage')
               .addStringOption(op => op.setName('question').setDescription('Question').setRequired(true)))
        .addSubcommand(sub => 
            sub.setName('voice').setDescription('Renommer vocal')
               .addStringOption(op => op.setName('nom').setDescription('Nouveau nom').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();

        // --- HELP ---
        if (sub === 'help') {
            const embed = new EmbedBuilder()
                .setTitle('📚 Aide Midnight')
                .setColor(0x7C6CFF)
                .setDescription('Voici les catégories de commandes :')
                .addFields(
                    { name: '🏢 Entreprise', value: '`/office` (Pointeuse, Facture...)', inline: true },
                    { name: '💰 Économie', value: '`/money` (Pay, Balance, Jeux)', inline: true },
                    { name: '📱 Social', value: '`/social` (Twitter, Insta...)', inline: true },
                    { name: '👮 Modération', value: '`/mod` (Ban, Kick...)', inline: true },
                    { name: '🎮 RP', value: '`/rp`, `/rputils`, `/gang`', inline: true }
                );
            return interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // --- POLL ---
        if (sub === 'poll') {
            const question = interaction.options.getString('question');
            const embed = new EmbedBuilder()
                .setTitle('📊 Sondage')
                .setDescription(question)
                .setColor(0xFFFF00)
                .setFooter({ text: `Proposé par ${interaction.user.username}` });

            const msg = await interaction.reply({ embeds: [embed], fetchReply: true });
            await msg.react('✅');
            await msg.react('❌');
            return;
        }
        
        // --- USERINFO ---
        if (sub === 'userinfo') {
             const target = interaction.options.getUser('target') || interaction.user;
             const embed = new EmbedBuilder()
                .setTitle(`👤 Infos : ${target.username}`)
                .setThumbnail(target.displayAvatarURL())
                .addFields(
                    { name: 'ID', value: target.id, inline: true },
                    { name: 'Compte créé le', value: target.createdAt.toLocaleDateString(), inline: true }
                );
             return interaction.reply({ embeds: [embed] });
        }

        // --- SERVERINFO ---
        if (sub === 'serverinfo') {
            const guild = interaction.guild;
            const embed = new EmbedBuilder()
               .setTitle(`📊 Infos : ${guild.name}`)
               .setThumbnail(guild.iconURL())
               .addFields(
                   { name: 'Membres', value: `${guild.memberCount}`, inline: true },
                   { name: 'Créé le', value: guild.createdAt.toLocaleDateString(), inline: true }
               );
            return interaction.reply({ embeds: [embed] });
       }

        // --- VOICE ---
        if (sub === 'voice') {
            const channel = interaction.member.voice.channel;
            if (!channel) return interaction.reply({ content: "❌ Tu n'es pas dans un vocal.", ephemeral: true });
            
            try {
                await channel.setName(interaction.options.getString('nom'));
                return interaction.reply("✅ Salon renommé.");
            } catch (e) {
                return interaction.reply({ content: "❌ Impossible (Permission manquante ou Rate Limit).", ephemeral: true });
            }
        }
    },
};