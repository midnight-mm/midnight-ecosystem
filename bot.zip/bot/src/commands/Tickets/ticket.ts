import { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder, AttachmentBuilder } from 'discord.js';
import { prisma } from '../../db';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Système de support complet')
        .addSubcommand(sub => sub.setName('create').setDescription('Ouvrir un ticket'))
        .addSubcommand(sub => sub.setName('close').setDescription('Fermer le ticket'))
        .addSubcommand(sub => sub.setName('claim').setDescription('Prendre en charge le ticket'))
        // --- AJOUTS ---
        .addSubcommand(sub => sub.setName('transcript').setDescription('📄 Sauvegarder la conversation (HTML/TXT)'))
        .addSubcommand(sub => 
            sub.setName('auto-reply').setDescription('🤖 Activer/Désactiver l\'IA de réponse')
               .addBooleanOption(op => op.setName('etat').setDescription('ON ou OFF').setRequired(true)))
        // --------------
        .addSubcommand(sub => 
            sub.setName('add').setDescription('Ajouter un membre')
               .addUserOption(op => op.setName('target').setDescription('Membre').setRequired(true)))
        .addSubcommand(sub => 
            sub.setName('remove').setDescription('Retirer un membre')
               .addUserOption(op => op.setName('target').setDescription('Membre').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();
        const guild = interaction.guild;
        const member = interaction.member;
        const channel = interaction.channel;
        const user = interaction.user;

        // 1. CREATE
        if (sub === 'create') {
            // Création du salon Discord
            const newChannel = await guild.channels.create({
                name: `ticket-${user.username}`,
                type: ChannelType.GuildText,
                parent: null, // À définir si tu as un ID de catégorie
                permissionOverwrites: [
                    { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                    { id: user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
                    { id: interaction.client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }
                ]
            });

            // --- SAUVEGARDE DB (Vital pour claim/close plus tard) ---
            try {
                // 1. Assurer que l'user existe en BDD
                const dbUser = await prisma.user.upsert({
                    where: { discordId: user.id },
                    create: { discordId: user.id, username: user.username },
                    update: { username: user.username }
                });

                // 2. Trouver ou créer une catégorie par défaut
                let category = await prisma.ticketCategory.findFirst({ where: { guildId: guild.id } });
                if (!category) {
                    category = await prisma.ticketCategory.create({ data: { name: "Défaut", guildId: guild.id } });
                }

                // 3. Créer le ticket
                await prisma.ticket.create({
                    data: {
                        guildId: guild.id,
                        channelId: newChannel.id,
                        creatorId: dbUser.id,
                        categoryId: category.id,
                        status: "OPEN"
                    }
                });
            } catch (error) {
                console.error("Erreur DB Ticket:", error);
            }

            await interaction.reply({ content: `✅ Ticket créé : ${newChannel}`, ephemeral: true });
            return newChannel.send(`👋 Bonjour ${user} ! Décrivez votre problème ici.`);
        }

        // VÉRIFICATION DE SÉCURITÉ : Est-on dans un ticket ?
        // (Sauf pour auto-reply qui est une config serveur)
        if (sub !== 'auto-reply' && !channel.name.startsWith('ticket-')) {
             return interaction.reply({ content: "❌ Cette commande s'utilise uniquement dans un salon ticket.", ephemeral: true });
        }

        // 2. CLOSE
        if (sub === 'close') {
            await interaction.reply("🔒 Fermeture du ticket dans 5 secondes...");
            
            // Mise à jour DB (Optionnel : Marquer comme CLOSED)
            /* await prisma.ticket.updateMany({
                where: { channelId: channel.id },
                data: { status: "CLOSED", closedAt: new Date() }
            }); 
            */

            setTimeout(() => interaction.channel.delete(), 5000);
            return;
        }

        // 3. CLAIM
        if (sub === 'claim') {
            await interaction.channel.send(`🙋‍♂️ Ce ticket est pris en charge par **${user.username}**.`);
            
            // Mise à jour DB : Assigner le staff
            const dbStaff = await prisma.user.findUnique({ where: { discordId: user.id } });
            if (dbStaff) {
                await prisma.ticket.updateMany({
                    where: { channelId: channel.id },
                    data: { assignedToId: dbStaff.id }
                });
            }

            await interaction.reply({ content: "Ticket assigné.", ephemeral: true });
            return;
        }

        // 4. TRANSCRIPT (AJOUTÉ)
        if (sub === 'transcript') {
            await interaction.deferReply();
            
            // Récupérer les 100 derniers messages
            const messages = await channel.messages.fetch({ limit: 100 });
            const logs = messages.reverse().map((m: any) => 
                `[${m.createdAt.toLocaleString()}] ${m.author.tag}: ${m.content}`
            ).join('\n');

            // Créer le fichier
            const attachment = new AttachmentBuilder(Buffer.from(logs, 'utf-8'), { name: `transcript-${channel.name}.txt` });

            return interaction.editReply({ 
                content: `📄 Voici l'historique de **${channel.name}** :`, 
                files: [attachment] 
            });
        }

        // 5. AUTO-REPLY (AJOUTÉ)
        if (sub === 'auto-reply') {
            const etat = interaction.options.getBoolean('etat');
            
            // Mise à jour de la config JSON du serveur
            const guildData = await prisma.guild.findUnique({ where: { id: guild.id } });
            const currentConfig = (guildData?.config as any) || {};
            currentConfig.autoReply = etat;

            await prisma.guild.update({
                where: { id: guild.id },
                data: { config: currentConfig }
            });

            return interaction.reply(`🤖 Réponse automatique IA : **${etat ? 'ACTIVÉE' : 'DÉSACTIVÉE'}**`);
        }

        // 6. ADD / REMOVE
        if (sub === 'add' || sub === 'remove') {
            const target = interaction.options.getUser('target');
            const hasPerm = sub === 'add'; // True = Allow, False = Deny

            await interaction.channel.permissionOverwrites.edit(target.id, {
                ViewChannel: hasPerm,
                SendMessages: hasPerm
            });

            return interaction.reply(`👤 **${target.username}** a été ${hasPerm ? 'ajouté' : 'retiré'} du ticket.`);
        }
    },
};