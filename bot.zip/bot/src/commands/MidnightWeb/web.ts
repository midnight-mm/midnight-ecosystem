import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { prisma } from '../../db';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('web')
        .setDescription('Services Midnight Web & Dev')
        .addSubcommand(sub => sub.setName('portfolio').setDescription('Voir nos réalisations'))
        .addSubcommand(sub => 
            sub.setName('domain').setDescription('Vérifier un nom de domaine')
               .addStringOption(op => op.setName('url').setDescription('Ex: monsite.com').setRequired(true)))
        .addSubcommand(sub => 
            sub.setName('status').setDescription('Suivi de votre projet web')
               .addStringOption(op => op.setName('id').setDescription('ID du Devis/Projet').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();

        if (sub === 'portfolio') {
            const embed = new EmbedBuilder()
                .setTitle('🎨 Portfolio Midnight Web')
                .setColor(0x0099FF)
                .setDescription('Quelques-unes de nos dernières créations :')
                .addFields(
                    { name: '🛒 E-commerce', value: '[Voir le projet](https://midnight.com)', inline: true },
                    { name: '🏢 Vitrine Entreprise', value: '[Voir le projet](https://midnight.com)', inline: true },
                    { name: '🎮 Dashboard FiveM', value: '[Voir le projet](https://midnight.com)', inline: true }
                )
                .setImage('https://placehold.co/600x300/png?text=Portfolio+Web'); // Image placeholder
            
            return interaction.reply({ embeds: [embed] });
        }

        if (sub === 'domain') {
            const url = interaction.options.getString('url');
            // Mock de vérification Whois
            const available = Math.random() < 0.5; // 50% de chance
            
            return interaction.reply({ 
                content: available 
                    ? `✅ Le domaine **${url}** est DISPONIBLE !` 
                    : `❌ Le domaine **${url}** est déjà pris.` 
            });
        }

        if (sub === 'status') {
            const projectId = interaction.options.getString('id');
            
            // On cherche dans la table Quote (Devis)
            const quote = await prisma.quote.findUnique({ where: { id: projectId } });

            if (!quote) return interaction.reply({ content: "❌ Projet introuvable.", ephemeral: true });

            const embed = new EmbedBuilder()
                .setTitle(`📊 Suivi Projet : ${quote.description.substring(0, 20)}...`)
                .setColor(0x7C6CFF)
                .addFields(
                    { name: 'Client', value: `${quote.firstName} ${quote.lastName}`, inline: true },
                    { name: 'Statut', value: quote.status, inline: true }, // PENDING, ACCEPTED...
                    { name: 'Budget', value: `${quote.budget} €`, inline: true },
                    { name: 'Deadline', value: quote.deadline || "Non définie", inline: true }
                );

            return interaction.reply({ embeds: [embed] });
        }
    },
};