import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('gang')
        .setDescription('Commandes illégales')
        // DARKCHAT
        .addSubcommand(sub => 
            sub.setName('darkchat').setDescription('Message anonyme')
               .addStringOption(op => op.setName('msg').setDescription('Message').setRequired(true)))
        // GO FAST
        .addSubcommand(sub => sub.setName('gofast').setDescription('Lancer un Go Fast'))
        // TERRITORY
        .addSubcommand(sub => sub.setName('territory').setDescription('Carte des zones'))
        // BOUNTY
        .addSubcommand(sub => 
            sub.setName('bounty').setDescription('Mettre un contrat')
               .addStringOption(op => op.setName('target').setDescription('Nom de la cible').setRequired(true))
               .addIntegerOption(op => op.setName('amount').setDescription('Montant').setRequired(true)))
        // CRAFTING
        .addSubcommand(sub => sub.setName('crafting').setDescription('Recettes illégales'))
        // LAUNDERING
        .addSubcommand(sub => 
            sub.setName('laundering').setDescription('Calcul blanchiment')
               .addIntegerOption(op => op.setName('amount').setDescription('Montant sale').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();

        // 1. DARKCHAT (Anonyme)
        if (sub === 'darkchat') {
            const message = interaction.options.getString('msg');
            const embed = new EmbedBuilder()
                .setColor(0x000000)
                .setAuthor({ name: 'DarkNet User #????', iconURL: 'https://cdn-icons-png.flaticon.com/512/2058/2058142.png' })
                .setDescription(`> ${message}`)
                .setFooter({ text: 'Connexion cryptée 🔒' });

            // On répond publiquement mais sans afficher le nom de l'auteur original
            return interaction.reply({ embeds: [embed] });
        }

        // 2. GO FAST
        if (sub === 'gofast') {
            await interaction.reply("🚤 **GO FAST LANCÉ !** Vous avez 15 minutes pour livrer le paquet au point Nord.");
            // Ici tu pourrais ajouter un setTimeout pour envoyer un message après 15min
            setTimeout(() => {
                interaction.followUp({ content: "⏰ **Temps écoulé !** Le Go Fast est terminé.", ephemeral: true }).catch(() => {});
            }, 5000); // 5 secondes pour la démo
            return;
        }

        // 3. TERRITORY
        if (sub === 'territory') {
            const embed = new EmbedBuilder()
                .setTitle('📍 Zones de Gangs')
                .setDescription('🟥 **Ballas :** Sud\n🟩 **Families :** Ouest\n🟨 **Vagos :** Est')
                .setColor(0xFF0000);
            return interaction.reply({ embeds: [embed] });
        }

        // 4. BOUNTY
        if (sub === 'bounty') {
            const target = interaction.options.getString('target');
            const amount = interaction.options.getInteger('amount');
            
            const embed = new EmbedBuilder()
                .setTitle('🎯 CONTRAT ACTIF')
                .setDescription(`Une prime de **${amount} $** a été placée sur la tête de : **${target}**.\n\n*Preuve requise pour paiement.*`)
                .setImage('https://media.giphy.com/media/r1jbtDXIAjq9y/giphy.gif')
                .setColor(0x8B0000); // Rouge sang
            
            return interaction.reply({ embeds: [embed] });
        }

        // 5. CRAFTING
        if (sub === 'crafting') {
            const embed = new EmbedBuilder()
                .setTitle('🛠️ Établi Clandestin')
                .addFields(
                    { name: '🔫 Pistolet (Pétoire)', value: '50x Fer, 10x Plastique', inline: true },
                    { name: '💊 Weed', value: '3x Feuilles de Coka', inline: true },
                    { name: '🔐 Crochet', value: '5x Métal', inline: true }
                );
            return interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // 6. LAUNDERING
        if (sub === 'laundering') {
            const sale = interaction.options.getInteger('amount');
            const taux = 0.70; // On récupère 70% (30% de perte)
            const propre = Math.floor(sale * taux);
            
            return interaction.reply({ 
                content: `💸 **Blanchiment :**\nArgent Sale : ${sale} $\nTaux : 30%\n\n👉 **Argent Propre reçu : ${propre} $**`, 
                ephemeral: true 
            });
        }
    },
};