import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('links')
        .setDescription('Affiche tous les liens de l\'écosystème Midnight'),
    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('🌐 Écosystème Midnight')
            .setColor(0x7C6CFF)
            .addFields(
                { name: '🛒 Boutique', value: '[Accéder au Shop](https://ton-site.com/shop)', inline: true },
                { name: '🎓 École', value: '[Midnight School](https://ton-site.com/school)', inline: true },
                { name: '🎮 Serveur RP', value: 'connect fivem.ton-serveur.com', inline: true },
            );
        await interaction.reply({ embeds: [embed] });
    },
};