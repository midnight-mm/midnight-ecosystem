import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { prisma } from '../../db'; // Ton instance Prisma

module.exports = {
    data: new SlashCommandBuilder()
        .setName('account')
        .setDescription('Gestion de votre compte Midnight')
        .addSubcommand(sub => 
            sub.setName('link').setDescription('Lier votre compte Discord au site web')),

    async execute(interaction: any) {
        // Simuler un lien vers le dashboard
        const userId = interaction.user.id;
        
        // On vérifie si l'user est déjà en DB
        const user = await prisma.user.findUnique({ where: { discordId: userId } });

        const embed = new EmbedBuilder()
            .setTitle('👤 Liaison de compte')
            .setColor(0x7C6CFF);

        if (user && user.email) {
             embed.setDescription(`✅ Votre compte est déjà lié à **${user.email}**.`);
        } else {
             // En production, tu générerais un token unique ici
             embed.setDescription(`Pour lier votre compte, rendez-vous sur votre tableau de bord :\n\n👉 **[Cliquez ici pour lier](https://midnight.com/dashboard/link?id=${userId})**`);
        }

        return interaction.reply({ embeds: [embed], ephemeral: true });
    },
};