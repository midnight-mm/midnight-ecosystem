import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('midnight')
        .setDescription('Commandes générales de l\'écosystème Midnight')
        .addSubcommand(sub => 
            sub.setName('status').setDescription('Affiche l\'état des services'))
        .addSubcommand(sub => 
            sub.setName('links').setDescription('Liens officiels'))
        .addSubcommand(sub => 
            sub.setName('social').setDescription('Nos réseaux sociaux')),

    async execute(interaction: any) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'status') {
            const embed = new EmbedBuilder()
                .setTitle('📡 État des Services Midnight')
                .setColor(0x00FF00)
                .addFields(
                    { name: '🌐 Site Web', value: '✅ En ligne', inline: true },
                    { name: '🛒 Boutique', value: '✅ En ligne', inline: true },
                    { name: '🎮 Serveur RP', value: '✅ En ligne (Joueurs: 124/200)', inline: true },
                    { name: '🤖 Bot API', value: '✅ Opérationnel', inline: true },
                )
                .setTimestamp();
            return interaction.reply({ embeds: [embed] });
        }

        if (subcommand === 'links') {
            const embed = new EmbedBuilder()
                .setTitle('🔗 Liens Officiels')
                .setColor(0x7C6CFF)
                .setDescription('Retrouvez tout notre écosystème ici :')
                .addFields(
                    { name: '🏠 Site Web', value: '[midnight.com](https://midnight.com)' },
                    { name: '🛒 Boutique', value: '[shop.midnight.com](https://shop.midnight.com)' },
                    { name: '🎓 École', value: '[school.midnight.com](https://school.midnight.com)' }
                );
            return interaction.reply({ embeds: [embed] });
        }

        if (subcommand === 'social') {
            const embed = new EmbedBuilder()
                .setTitle('📱 Nos Réseaux Sociaux')
                .setColor(0xFF0050)
                .setDescription('Suivez-nous pour ne rien rater !')
                .addFields(
                    { name: '🐦 Twitter/X', value: '[Suivre](https://twitter.com/midnight)', inline: true },
                    { name: '🎵 TikTok', value: '[Voir](https://tiktok.com/@midnight)', inline: true },
                    { name: '📹 YouTube', value: '[S\'abonner](https://youtube.com/midnight)', inline: true }
                );
            return interaction.reply({ embeds: [embed] });
        }
    },
};