import { SlashCommandBuilder } from 'discord.js';
import { prisma } from '../../db';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('daily')
        .setDescription('Récupère ta récompense journalière'),
    
    async execute(interaction: any) {
        const discordId = interaction.user.id;
        
        try {
            // 1. D'abord, on s'assure que l'utilisateur existe en BDD et on RÉCUPÈRE son UUID
            const dbUser = await prisma.user.upsert({
                where: { discordId: discordId },
                create: { 
                    discordId: discordId, 
                    username: interaction.user.username 
                },
                update: {
                    username: interaction.user.username // On en profite pour mettre à jour le pseudo
                }
            });

            // 2. Maintenant on cherche l'économie avec l'UUID interne (dbUser.id)
            let eco = await prisma.economy.findUnique({ 
                where: { userId: dbUser.id } 
            });
            
            // 3. Si l'économie n'existe pas, on la crée avec le bon UUID
            if (!eco) {
                eco = await prisma.economy.create({ 
                    data: { userId: dbUser.id } // 👈 C'est ici que ça plantait avant
                });
            }

            // 4. Vérifier le temps (24h = 86400000 ms)
            const now = new Date();
            if (eco.lastDaily && (now.getTime() - eco.lastDaily.getTime()) < 86400000) {
                // Calcul du temps restant pour faire joli
                const timeLeft = 86400000 - (now.getTime() - eco.lastDaily.getTime());
                const hours = Math.floor(timeLeft / (1000 * 60 * 60));
                const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));

                return interaction.reply({ 
                    content: `⏳ Tu as déjà récupéré ta récompense. Reviens dans **${hours}h ${minutes}m** !`, 
                    ephemeral: true 
                });
            }

            // 5. Donner l'argent (Mise à jour via UUID)
            await prisma.economy.update({
                where: { userId: dbUser.id },
                data: { 
                    wallet: { increment: 500 }, 
                    lastDaily: now 
                }
            });

            await interaction.reply(`💰 Tu as reçu **500 MidnightCoins** !`);

        } catch (error) {
            console.error("Erreur commande Daily:", error);
            await interaction.reply({ content: "❌ Une erreur système est survenue.", ephemeral: true });
        }
    },
};