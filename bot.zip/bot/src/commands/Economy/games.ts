import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';
import { prisma } from '../../db';

// Helper pour récupérer l'économie
async function getEconomy(userId: string, username: string) {
    const dbUser = await prisma.user.upsert({
        where: { discordId: userId },
        create: { discordId: userId, username: username },
        update: { username: username }
    });
    
    let eco = await prisma.economy.findUnique({ where: { userId: dbUser.id } });
    if (!eco) eco = await prisma.economy.create({ data: { userId: dbUser.id } });
    
    return { eco, dbUser };
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('money')
        .setDescription('Gestion économie et jeux')
        .addSubcommand(sub => sub.setName('balance').setDescription('Voir mon solde'))
        .addSubcommand(sub => 
            sub.setName('pay').setDescription('Envoyer de l\'argent')
               .addUserOption(op => op.setName('membre').setDescription('Destinataire').setRequired(true))
               .addIntegerOption(op => op.setName('montant').setDescription('Montant').setRequired(true)))
        .addSubcommand(sub => 
            sub.setName('coinflip').setDescription('Pile ou Face')
               .addIntegerOption(op => op.setName('mise').setDescription('Mise').setRequired(true)))
        .addSubcommand(sub => 
            sub.setName('rob').setDescription('Braquer un joueur')
               .addUserOption(op => op.setName('victime').setDescription('Victime').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();
        const user = interaction.user;

        // --- BALANCE ---
        if (sub === 'balance') {
            const { eco } = await getEconomy(user.id, user.username);
            const embed = new EmbedBuilder()
                .setTitle(`💰 Portefeuille de ${user.username}`)
                .setColor(0xF1C40F)
                .addFields(
                    { name: '💶 Espèces', value: `${eco.wallet} 🪙`, inline: true },
                    { name: '🏦 Banque', value: `${eco.bank} 🪙`, inline: true }
                );
            return interaction.reply({ embeds: [embed] });
        }

        // --- PAY (Virement) ---
        if (sub === 'pay') {
            const target = interaction.options.getUser('membre');
            const amount = interaction.options.getInteger('montant');

            if (amount <= 0) return interaction.reply("❌ Montant invalide.");
            if (target.id === user.id) return interaction.reply("❌ Tu ne peux pas t'envoyer de l'argent.");

            const senderData = await getEconomy(user.id, user.username);
            const receiverData = await getEconomy(target.id, target.username);

            if (senderData.eco.wallet < amount) {
                return interaction.reply("❌ Tu n'as pas assez d'argent liquide.");
            }

            // Transaction atomique
            await prisma.$transaction([
                prisma.economy.update({
                    where: { id: senderData.eco.id },
                    data: { wallet: { decrement: amount } }
                }),
                prisma.economy.update({
                    where: { id: receiverData.eco.id },
                    data: { wallet: { increment: amount } }
                })
            ]);

            return interaction.reply(`💸 **Transfert réussi !** Tu as envoyé **${amount} 🪙** à ${target}.`);
        }

        // --- COINFLIP ---
        if (sub === 'coinflip') {
            const mise = interaction.options.getInteger('mise');
            if (mise <= 0) return interaction.reply("❌ Mise invalide.");

            const { eco, dbUser } = await getEconomy(user.id, user.username);
            if (eco.wallet < mise) return interaction.reply("❌ Pas assez d'argent.");

            const win = Math.random() > 0.5;

            if (win) {
                await prisma.economy.update({ where: { userId: dbUser.id }, data: { wallet: { increment: mise } } });
                return interaction.reply(`🟢 **GAGNÉ !** C'était PILE. Tu remportes **${mise * 2} 🪙**.`);
            } else {
                await prisma.economy.update({ where: { userId: dbUser.id }, data: { wallet: { decrement: mise } } });
                return interaction.reply(`🔴 **PERDU...** C'était FACE. Tu perds ta mise.`);
            }
        }

        // --- ROB (Vol) ---
        if (sub === 'rob') {
            const target = interaction.options.getUser('victime');
            if (target.id === user.id) return interaction.reply("❌ Tu ne peux pas te voler.");

            const thiefData = await getEconomy(user.id, user.username);
            const victimData = await getEconomy(target.id, target.username);

            if (victimData.eco.wallet < 100) return interaction.reply("❌ Cette personne n'a rien sur elle.");

            const success = Math.random() > 0.6; // 40% de chance de réussite

            if (success) {
                const stolen = Math.floor(Math.random() * (victimData.eco.wallet / 2)); // Max 50% du wallet
                await prisma.economy.update({ where: { id: victimData.eco.id }, data: { wallet: { decrement: stolen } } });
                await prisma.economy.update({ where: { id: thiefData.eco.id }, data: { wallet: { increment: stolen } } });
                return interaction.reply(`🥷 **VOL RÉUSSI !** Tu as dérobé **${stolen} 🪙** à ${target}.`);
            } else {
                const fine = 200;
                await prisma.economy.update({ where: { id: thiefData.eco.id }, data: { wallet: { decrement: fine } } });
                return interaction.reply(`🚔 **ÉCHEC !** La police t'a attrapé. Amende : **${fine} 🪙**.`);
            }
        }
    },
};