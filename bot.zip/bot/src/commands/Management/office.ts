import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';

// Mémoire temporaire pour la pointeuse (Reset au redémarrage)
const timeSheet = new Map<string, number>();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('office')
        .setDescription('Outils de gestion d\'entreprise et staff')
        // RH & STAFF
        .addSubcommand(sub => sub.setName('pointeuse').setDescription('Débuter/Finir son service'))
        .addSubcommand(sub => 
            sub.setName('absence').setDescription('Déclarer une absence')
               .addStringOption(op => op.setName('dates').setDescription('Ex: 12/05 au 15/05').setRequired(true))
               .addStringOption(op => op.setName('motif').setDescription('Raison').setRequired(true)))
        // PROJET
        .addSubcommand(sub => 
            sub.setName('kanban').setDescription('Créer un tableau de tâches')
               .addStringOption(op => op.setName('projet').setDescription('Nom du projet').setRequired(true)))
        .addSubcommand(sub => sub.setName('meeting').setDescription('Lancer une réunion vocale'))
        // CRM & FACTURATION
        .addSubcommand(sub => 
            sub.setName('invoice').setDescription('Générer une facture')
               .addUserOption(op => op.setName('client').setDescription('Client').setRequired(true))
               .addIntegerOption(op => op.setName('montant').setDescription('Montant (€)').setRequired(true)))
        .addSubcommand(sub => 
            sub.setName('it').setDescription('Ouvrir un ticket Support IT (Interne)')
               .addStringOption(op => op.setName('probleme').setDescription('Description du bug').setRequired(true)))
        .addSubcommand(sub => 
            sub.setName('workmode').setDescription('Activer le mode Concentration')
               .addBooleanOption(op => op.setName('active').setDescription('ON/OFF').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();
        const user = interaction.user;

        // --- POINTEUSE ---
        if (sub === 'pointeuse') {
            if (timeSheet.has(user.id)) {
                const start = timeSheet.get(user.id)!;
                const duration = Math.floor((Date.now() - start) / 1000 / 60); // Minutes
                timeSheet.delete(user.id);
                return interaction.reply(`⏱️ **Fin de service.** Vous avez travaillé **${duration} minutes**.`);
            } else {
                timeSheet.set(user.id, Date.now());
                return interaction.reply(`⏱️ **Début de service.** Bon courage ${user} !`);
            }
        }

        // --- ABSENCE ---
        if (sub === 'absence') {
            // Idéalement, envoie ça dans un salon #rh-logs
            return interaction.reply({ 
                content: `✅ Demande d'absence enregistrée pour **${interaction.options.getString('dates')}**.\nMotif : ${interaction.options.getString('motif')}`, 
                ephemeral: true 
            });
        }

        // --- KANBAN (Projet) ---
        if (sub === 'kanban') {
            const projet = interaction.options.getString('projet');
            const embed = new EmbedBuilder()
                .setTitle(`📋 KANBAN : ${projet}`)
                .setColor(0x0099FF)
                .addFields(
                    { name: '📝 À FAIRE', value: '- Tâche 1\n- Tâche 2', inline: true },
                    { name: '🔨 EN COURS', value: '- Tâche 3', inline: true },
                    { name: '✅ TERMINÉ', value: '- Configuration Bot', inline: true }
                )
                .setFooter({ text: 'Utilisez /task add pour modifier' });
            return interaction.reply({ embeds: [embed] });
        }

        // --- MEETING ---
        if (sub === 'meeting') {
            const channel = await interaction.guild.channels.create({
                name: `Meeting-${user.username}`,
                type: ChannelType.GuildVoice,
                limit: 10
            });
            return interaction.reply(`🎙️ **Réunion lancée !** Rejoignez le salon vocal : ${channel}`);
        }

        // --- INVOICE (Facture) ---
        if (sub === 'invoice') {
            const client = interaction.options.getUser('client');
            const montant = interaction.options.getInteger('montant');
            
            const embed = new EmbedBuilder()
                .setTitle('🧾 FACTURE #2024-001')
                .setDescription(`**Émise par :** Midnight Corp\n**Pour :** ${client.username}`)
                .addFields(
                    { name: 'Service', value: 'Développement Web/Bot', inline: true },
                    { name: 'Total à payer', value: `**${montant} €**`, inline: true },
                    { name: 'Échéance', value: '30 jours', inline: true }
                )
                .setColor(0xFFFFFF);
            
            return interaction.reply({ content: `${client}`, embeds: [embed] });
        }

        // --- IT REQUEST ---
        if (sub === 'it') {
            return interaction.reply({ 
                content: `💻 **Ticket IT ouvert :** "${interaction.options.getString('probleme')}"\nLe service technique a été notifié.`, 
                ephemeral: true 
            });
        }

        // --- WORKMODE ---
        if (sub === 'workmode') {
            const active = interaction.options.getBoolean('active');
            // Logique : Tu pourrais donner un rôle "Focus" qui cache les salons jeux
            return interaction.reply({ 
                content: active 
                    ? "📵 **Mode Focus ACTIVÉ.** Les notifications de jeux sont masquées." 
                    : "🔔 **Mode Focus DÉSACTIVÉ.**", 
                ephemeral: true 
            });
        }
    },
};