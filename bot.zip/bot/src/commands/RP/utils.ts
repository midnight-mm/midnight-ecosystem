import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('utils')
        .setDescription('Outils RP')
        .addSubcommand(sub => 
            sub.setName('roll').setDescription('Lancer les dés')
               .addIntegerOption(op => op.setName('max').setDescription('Chiffre max (defaut 100)')))
        .addSubcommand(sub => 
            sub.setName('idcard').setDescription('Voir la carte d\'identité')
               .addUserOption(op => op.setName('membre').setDescription('Cible'))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();

        if (sub === 'roll') {
            const max = interaction.options.getInteger('max') || 100;
            const result = Math.floor(Math.random() * max) + 1;
            
            // Logique Win/Fail simple
            const color = result > (max / 2) ? 0x00FF00 : 0xFF0000;
            
            const embed = new EmbedBuilder()
                .setTitle(`🎲 Dés (1-${max})`)
                .setDescription(`Le joueur **${interaction.user.username}** a fait : **${result}**`)
                .setColor(color);
            
            return interaction.reply({ embeds: [embed] });
        }

        if (sub === 'idcard') {
            const target = interaction.options.getUser('membre') || interaction.user;
            const embed = new EmbedBuilder()
                .setTitle('🪪 Carte d\'identité : San Andreas')
                .setThumbnail(target.displayAvatarURL())
                .setColor(0xFFFFFF)
                .addFields(
                    { name: 'Nom', value: target.username.toUpperCase(), inline: true },
                    { name: 'Prénom', value: 'Inconnu', inline: true },
                    { name: 'Date de naissance', value: '01/01/2000', inline: true },
                    { name: 'Sexe', value: 'H', inline: true }
                );
            return interaction.reply({ embeds: [embed] });
        }
    },
};