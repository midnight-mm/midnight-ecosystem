import { SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ActionRowBuilder, ButtonStyle } from 'discord.js';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rp')
        .setDescription('Commandes Roleplay Générales')
        .addSubcommand(sub => sub.setName('connect').setDescription('Se connecter au serveur'))
        .addSubcommand(sub => sub.setName('status').setDescription('État du serveur'))
        .addSubcommand(sub => sub.setName('whitelist').setDescription('Vérifier ma Whitelist'))
        .addSubcommand(sub => sub.setName('mapping').setDescription('Voir la carte'))
        .addSubcommand(sub => sub.setName('charinfo').setDescription('Infos de mon personnage')),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();

        // 1. CONNECT
        if (sub === 'connect') {
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
                new ButtonBuilder()
                    .setLabel('🎮 Rejoindre (F8)')
                    .setStyle(ButtonStyle.Link)
                    .setURL('https://cfx.re/join/ton-serveur-id') // Remplace par ton lien
            );
            return interaction.reply({ content: "**🚀 Prêt à rejoindre Los Santos ?**", components: [row] });
        }

        // 2. STATUS
        if (sub === 'status') {
            const embed = new EmbedBuilder()
                .setTitle('🟢 Midnight RP - Statut')
                .setColor(0x00FF00)
                .addFields(
                    { name: 'État', value: '✅ En Ligne', inline: true },
                    { name: 'Joueurs', value: '👥 64/128', inline: true },
                    { name: 'Ping', value: '📡 12ms', inline: true }
                );
            return interaction.reply({ embeds: [embed] });
        }

        // 3. WHITELIST
        if (sub === 'whitelist') {
            // Simulation : On dit que tout le monde est WL pour l'instant
            return interaction.reply("✅ **Félicitations !** Vous êtes bien Whitelisté sur le serveur.");
        }

        // 4. CHARINFO (Infos Personnage)
        if (sub === 'charinfo') {
            const embed = new EmbedBuilder()
                .setTitle(`👤 Personnage : ${interaction.user.username}`)
                .setColor(0x3498DB)
                .addFields(
                    { name: 'Nom RP', value: 'John Doe', inline: true },
                    { name: 'Métier', value: 'Chômeur', inline: true },
                    { name: 'Argent (Cash)', value: '500 $', inline: true },
                    { name: 'Banque', value: '12,000 $', inline: true }
                );
            return interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // 5. MAPPING
        if (sub === 'mapping') {
            const embed = new EmbedBuilder()
                .setTitle('🗺️ Carte de Los Santos')
                .setImage('https://i.imgur.com/P3a1i0q.jpeg') // Lien vers une map GTA
                .setDescription("🔴 Zone Illégale | 🔵 Zone Safe | 🟢 Zone Neutre");
            return interaction.reply({ embeds: [embed] });
        }
    },
};