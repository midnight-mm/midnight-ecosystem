import { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } from 'discord.js';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bot')
        .setDescription('Services Midnight Bot')
        .addSubcommand(sub => sub.setName('order').setDescription('Commander un bot personnalisé'))
        .addSubcommand(sub => sub.setName('demo').setDescription('Voir une démo des fonctionnalités'))
        .addSubcommand(sub => sub.setName('hosting').setDescription('État de votre hébergement'))
        .addSubcommand(sub => 
            sub.setName('token').setDescription('Régénérer votre token client')
               .addStringOption(op => op.setName('confirmation').setDescription('Tapez "CONFIRM"').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();

        if (sub === 'order') {
            const row = new ActionRowBuilder<ButtonBuilder>()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Commander sur le site')
                        .setStyle(ButtonStyle.Link)
                        .setURL('https://midnight.com/shop/bots'),
                    new ButtonBuilder()
                        .setCustomId('contact_sales')
                        .setLabel('Contacter un commercial')
                        .setStyle(ButtonStyle.Primary)
                );

            return interaction.reply({ 
                content: "🤖 **Envie d'un bot sur mesure ?** Cliquez ci-dessous pour démarrer votre projet.", 
                components: [row] 
            });
        }

        if (sub === 'hosting') {
            // Simulation : Récupérer les données via API Pterodactyl ou BDD
            const embed = new EmbedBuilder()
                .setTitle('🔌 État de l\'hébergement')
                .setColor(0x00FF00)
                .addFields(
                    { name: 'Statut', value: '🟢 En Ligne', inline: true },
                    { name: 'Uptime', value: '99.9%', inline: true },
                    { name: 'RAM Utilisée', value: '450MB / 1024MB', inline: true },
                    { name: 'Expiration', value: '📅 12/12/2025', inline: true }
                );
            return interaction.reply({ embeds: [embed], ephemeral: true });
        }

        if (sub === 'token') {
            const confirm = interaction.options.getString('confirmation');
            if (confirm !== 'CONFIRM') return interaction.reply({ content: "❌ Tapez CONFIRM en majuscules pour valider.", ephemeral: true });

            return interaction.reply({ 
                content: "🔑 **Nouveau Token généré :** `MTE... (Caché)`\n⚠️ Ne le partagez à personne. Il a été envoyé sur votre dashboard.", 
                ephemeral: true 
            });
        }

        if (sub === 'demo') {
            return interaction.reply("🎮 **Démo interactive :**\n- Système de Tickets : ✅\n- Modération Auto : ✅\n- Économie : ✅\n\n*Utilisez les commandes pour tester !*");
        }
    },
};