import { SlashCommandBuilder, EmbedBuilder, ChannelType, PermissionFlagsBits } from 'discord.js';
import { prisma } from '../../db';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('school')
        .setDescription('Midnight School : Apprenez le dev et le RP')
        .addSubcommand(sub => sub.setName('mycourses').setDescription('Mes cours actifs'))
        .addSubcommand(sub => sub.setName('certificate').setDescription('Générer mon diplôme'))
        .addSubcommand(sub => 
            sub.setName('exam').setDescription('Lancer un examen')
               .addStringOption(op => op.setName('id').setDescription('ID du cours').setRequired(true)))
        .addSubcommand(sub => 
            sub.setName('mentor').setDescription('Demander l\'aide d\'un formateur')
               .addUserOption(op => op.setName('coach').setDescription('Le formateur').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();
        const user = interaction.user;

        // --- MES COURS ---
        if (sub === 'mycourses') {
            // On cherche les produits de type 'MidnightSchool' achetés par l'user
            // Note: C'est une requête complexe Prisma, on simplifie pour l'exemple
            // On va chercher si l'user a des Commandes (Order) contenant des produits de type School
            
            const embed = new EmbedBuilder()
                .setTitle('🎒 Mes Cours Midnight School')
                .setColor(0xFFA500)
                .setDescription('Voici vos formations en cours :')
                .addFields(
                    { name: '💻 Développement FiveM (Lua)', value: 'Progression : ▓▓▓▓▓░░░░░ 50%', inline: false },
                    { name: '🎨 Mapping 3D', value: 'Progression : ▓▓░░░░░░░░ 20%', inline: false }
                );

            return interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // --- EXAMEN ---
        if (sub === 'exam') {
            await interaction.reply({ content: "📩 Je vous ai envoyé l'examen en Message Privé !", ephemeral: true });
            return user.send({
                content: "📝 **EXAMEN : Développement FiveM**\n\nQuestion 1 : Quelle fonction permet d'afficher une notification en Lua ?\nA) ShowNotification()\nB) ESX.ShowNotification()\nC) print()\n\n*Répondez A, B ou C.*"
            }).catch(() => interaction.followUp({ content: "❌ Impossible de vous envoyer un MP. Ouvrez vos DM !", ephemeral: true }));
        }

        // --- CERTIFICAT ---
        if (sub === 'certificate') {
            // Simulation de génération d'image
            const embed = new EmbedBuilder()
                .setTitle('🎓 Félicitations !')
                .setDescription(`Bravo **${user.username}**, vous avez validé la formation "Développement Avancé".`)
                .setImage('https://placehold.co/600x400/EEE/31343C?text=DIPLOME+CERTIFIE')
                .setColor(0xD4AF37); // Or

            return interaction.reply({ embeds: [embed] });
        }

        // --- MENTOR ---
        if (sub === 'mentor') {
            const coach = interaction.options.getUser('coach');
            const guild = interaction.guild;

            // Création d'un fil privé ou salon
            const thread = await (interaction.channel as any).threads.create({
                name: `Mentoring-${user.username}`,
                autoArchiveDuration: 60,
                type: ChannelType.PrivateThread,
                reason: 'Session de mentoring'
            });

            await thread.members.add(user.id);
            await thread.members.add(coach.id);

            await interaction.reply({ content: `✅ Session de mentoring créée : <#${thread.id}>`, ephemeral: true });
            return thread.send(`👋 Bonjour ${coach}, l'élève ${user} a besoin d'aide sur un cours.`);
        }
    },
};