import { SlashCommandBuilder, PermissionFlagsBits, ChannelType, EmbedBuilder } from 'discord.js';
import { prisma } from '../../db';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('config')
        .setDescription('Configuration du serveur')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        
        // --- SOUS-COMMANDE : LOGS ---
        .addSubcommand(sub => 
            sub.setName('logs').setDescription('Définir les salons de logs')
               .addStringOption(op => op.setName('type').setDescription('Type de log').setRequired(true)
                    .addChoices(
                        { name: '🛡️ Modération (Ban/Kick)', value: 'mod' },
                        { name: '🎫 Tickets', value: 'ticket' },
                        { name: '👋 Arrivées/Départs', value: 'join' },
                        { name: '💰 Économie/Vente', value: 'eco' }
                    ))
               .addChannelOption(op => op.setName('salon').setDescription('Le salon de destination').setRequired(true)))

        // --- SOUS-COMMANDE : WELCOME ---
        .addSubcommand(sub => 
            sub.setName('welcome').setDescription('Configurer le message de bienvenue')
               .addChannelOption(op => op.setName('salon').setDescription('Salon de bienvenue').setRequired(true))
               .addBooleanOption(op => op.setName('actif').setDescription('Activer ?').setRequired(true))
               .addStringOption(op => op.setName('message').setDescription('Message ({user} mentionne le membre)')))

        // --- SOUS-COMMANDE : LINKS ---
        .addSubcommand(sub => 
            sub.setName('links').setDescription('Mettre à jour les liens du bot')
               .addStringOption(op => op.setName('site').setDescription('URL du site'))
               .addStringOption(op => op.setName('boutique').setDescription('URL boutique'))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        // 1. Récupérer la config actuelle
        const guildData = await prisma.guild.findUnique({ where: { id: guildId } });
        let currentConfig = (guildData?.config as any) || {};

        // --- LOGIQUE LOGS ---
        if (sub === 'logs') {
            const type = interaction.options.getString('type');
            const channel = interaction.options.getChannel('salon');

            if (channel.type !== ChannelType.GuildText) {
                return interaction.reply({ content: "❌ Veuillez choisir un salon textuel.", ephemeral: true });
            }

            // Structure : config.logs.mod = ID
            if (!currentConfig.logs) currentConfig.logs = {};
            currentConfig.logs[type] = channel.id;

            await prisma.guild.update({
                where: { id: guildId },
                data: { config: currentConfig }
            });

            return interaction.reply(`✅ Les logs **${type}** seront envoyés dans ${channel}.`);
        }

        // --- LOGIQUE WELCOME ---
        if (sub === 'welcome') {
            const channel = interaction.options.getChannel('salon');
            const actif = interaction.options.getBoolean('actif');
            const message = interaction.options.getString('message') || "Bienvenue {user} !";

            currentConfig.welcome = {
                channelId: channel.id,
                active: actif,
                message: message
            };

            await prisma.guild.update({
                where: { id: guildId },
                data: { config: currentConfig }
            });

            return interaction.reply(`✅ Bienvenue configuré dans ${channel}.\nMessage : "${message}"`);
        }

        // --- LOGIQUE LINKS (Global Site Config) ---
        if (sub === 'links') {
            const site = interaction.options.getString('site');
            const shop = interaction.options.getString('boutique');

            // Mise à jour de la table SiteConfig (Globale)
            // Note: Normalement, c'est fait via le Dashboard Web, mais on peut le faire ici
            await prisma.siteConfig.upsert({
                where: { id: 'global' },
                create: { 
                    siteName: 'Midnight',
                    socialLinks: { website: site, shop: shop }
                },
                update: {
                    socialLinks: { website: site, shop: shop }
                }
            });

            return interaction.reply("✅ Les liens globaux ont été mis à jour.");
        }
    },
};