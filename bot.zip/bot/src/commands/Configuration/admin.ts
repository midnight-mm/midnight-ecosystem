import { 
    SlashCommandBuilder, 
    EmbedBuilder, 
    ActionRowBuilder, 
    StringSelectMenuBuilder, 
    PermissionFlagsBits, 
    ChannelSelectMenuBuilder, 
    ChannelType, 
    ButtonBuilder, 
    ButtonStyle, 
    ComponentType 
} from 'discord.js';
import { prisma } from '../../db';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('admin')
        .setDescription('Ouvrir le panneau de configuration général')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction: any) {
        const guildId = interaction.guild.id;
        
        // 1. Charger la config actuelle
        let guildData = await prisma.guild.findUnique({ where: { id: guildId } });
        if (!guildData) {
            guildData = await prisma.guild.create({ data: { id: guildId, name: interaction.guild.name, ownerId: interaction.guild.ownerId } });
        }
        let config = (guildData.config as any) || {};

        // --- FONCTION : GÉNÉRER L'ACCUEIL ---
        const getMainMenu = () => {
            const embed = new EmbedBuilder()
                .setTitle('🎛️ Midnight - Panneau Administrateur')
                .setDescription('Sélectionnez un module ci-dessous pour le configurer.')
                .setColor(0x2B2D31)
                .addFields(
                    { name: '🛡️ Sécurité', value: `Anti-Raid: ${config.antiraid ? '✅' : '❌'}`, inline: true },
                    { name: '📝 Logs', value: config.logs?.mod ? `<#${config.logs.mod}>` : 'Non défini', inline: true },
                    { name: '👋 Bienvenue', value: config.welcome?.active ? '✅' : '❌', inline: true }
                );

            const row = new ActionRowBuilder<StringSelectMenuBuilder>()
                .addComponents(
                    new StringSelectMenuBuilder()
                        .setCustomId('admin_select_module')
                        .setPlaceholder('Choisir un module à configurer...')
                        .addOptions(
                            { label: 'Sécurité & Anti-Raid', value: 'module_security', emoji: '🛡️' },
                            { label: 'Configuration des Logs', value: 'module_logs', emoji: '📝' },
                            { label: 'Bienvenue & Au revoir', value: 'module_welcome', emoji: '👋' },
                            { label: 'Rôles & Permissions', value: 'module_roles', emoji: '👮' },
                            { label: 'Fermer le panneau', value: 'close_panel', emoji: '❌' },
                        )
                );

            return { embeds: [embed], components: [row] };
        };

        // Envoi du message initial
        const response = await interaction.reply({ ...getMainMenu(), fetchReply: true });

        // --- CRÉATION DU COLLECTEUR (ÉCOUTE DES CLICS PENDANT 5 MINUTES) ---
        const collector = response.createMessageComponentCollector({ 
            componentType: ComponentType.StringSelect, 
            time: 300000 
        });

        // Gestion des menus déroulants
        collector.on('collect', async (i: any) => {
            if (i.user.id !== interaction.user.id) {
                return i.reply({ content: "⛔ Ce panneau n'est pas pour vous.", ephemeral: true });
            }

            const selection = i.values[0];

            // 1. MODULE LOGS
            if (selection === 'module_logs') {
                const embed = new EmbedBuilder()
                    .setTitle('📝 Configuration des Logs')
                    .setDescription('Sélectionnez le salon où les logs de modération doivent être envoyés.')
                    .setColor(0xF1C40F);

                const channelSelect = new ActionRowBuilder<ChannelSelectMenuBuilder>()
                    .addComponents(
                        new ChannelSelectMenuBuilder()
                            .setCustomId('set_log_channel')
                            .setPlaceholder('Choisir le salon de logs...')
                            .setChannelTypes(ChannelType.GuildText)
                    );
                
                const backRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                    new ButtonBuilder().setCustomId('back_home').setLabel('Retour').setStyle(ButtonStyle.Secondary)
                );

                await i.update({ embeds: [embed], components: [channelSelect, backRow] });
            }

            // 2. MODULE SECURITE
            if (selection === 'module_security') {
                const isAntiRaidOn = config.antiraid || false;

                const embed = new EmbedBuilder()
                    .setTitle('🛡️ Sécurité Serveur')
                    .setDescription(`État actuel de l'Anti-Raid : **${isAntiRaidOn ? 'ACTIVÉ 🚨' : 'DÉSACTIVÉ 🟢'}**`)
                    .setColor(isAntiRaidOn ? 0xFF0000 : 0x00FF00);

                const btnRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                    new ButtonBuilder()
                        .setCustomId('toggle_antiraid')
                        .setLabel(isAntiRaidOn ? 'Désactiver Anti-Raid' : 'Activer Anti-Raid')
                        .setStyle(isAntiRaidOn ? ButtonStyle.Success : ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId('back_home').setLabel('Retour').setStyle(ButtonStyle.Secondary)
                );

                await i.update({ embeds: [embed], components: [btnRow] });
            }

            // 3. RETOUR ACCUEIL (Si géré via SelectMenu "Fermer")
            if (selection === 'close_panel') {
                await i.update({ content: "✅ Configuration terminée.", components: [], embeds: [] });
                collector.stop();
            }
        });

        // --- COLLECTEUR SECONDAIRE POUR LES BOUTONS & CHANNEL SELECT ---
        const subCollector = response.createMessageComponentCollector({ 
            filter: (u: any) => u.user.id === interaction.user.id,
            time: 300000 
        });

        subCollector.on('collect', async (i: any) => {
            // RETOUR ACCUEIL
            if (i.customId === 'back_home') {
                // On recharge la config fraîche
                const newGuildData = await prisma.guild.findUnique({ where: { id: guildId } });
                config = newGuildData?.config || {};
                await i.update(getMainMenu());
            }

            // ACTION : CHANGER SALON LOGS
            if (i.isChannelSelectMenu() && i.customId === 'set_log_channel') {
                const channelId = i.values[0];
                
                // Save DB
                if (!config.logs) config.logs = {};
                config.logs.mod = channelId; // On définit le log 'mod' par défaut ici

                await prisma.guild.update({ where: { id: guildId }, data: { config } });

                await i.reply({ content: `✅ Salon de logs défini sur <#${channelId}>`, ephemeral: true });
                // On retourne au menu
                // (Note: i.reply ne met pas à jour le menu, il faut que l'user clique sur Retour pour voir le changement dans le menu principal)
            }

            // ACTION : TOGGLE ANTI-RAID
            if (i.isButton() && i.customId === 'toggle_antiraid') {
                const newState = !config.antiraid;
                config.antiraid = newState;

                await prisma.guild.update({ where: { id: guildId }, data: { config } });

                // Mise à jour visuelle immédiate du bouton
                const embed = new EmbedBuilder()
                    .setTitle('🛡️ Sécurité Serveur')
                    .setDescription(`État actuel de l'Anti-Raid : **${newState ? 'ACTIVÉ 🚨' : 'DÉSACTIVÉ 🟢'}**`)
                    .setColor(newState ? 0xFF0000 : 0x00FF00);

                const btnRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
                    new ButtonBuilder()
                        .setCustomId('toggle_antiraid')
                        .setLabel(newState ? 'Désactiver Anti-Raid' : 'Activer Anti-Raid')
                        .setStyle(newState ? ButtonStyle.Success : ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId('back_home').setLabel('Retour').setStyle(ButtonStyle.Secondary)
                );

                await i.update({ embeds: [embed], components: [btnRow] });
            }
        });
    },
};