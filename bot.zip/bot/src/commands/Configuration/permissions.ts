import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from 'discord.js';
import { prisma } from '../../db';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('perms')
        .setDescription('Gérer qui peut utiliser quelle commande')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(sub => 
            sub.setName('set').setDescription('Autoriser/Interdire un rôle')
               .addStringOption(op => op.setName('commande').setDescription('Nom de la commande (ex: mdt)').setRequired(true))
               .addRoleOption(op => op.setName('role').setDescription('Le rôle concerné').setRequired(true))
               .addBooleanOption(op => op.setName('autoriser').setDescription('Vrai = Autorisé, Faux = Interdit').setRequired(true)))
        .addSubcommand(sub => 
            sub.setName('list').setDescription('Voir les permissions actives')),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        if (sub === 'set') {
            const cmd = interaction.options.getString('commande');
            const role = interaction.options.getRole('role');
            const allow = interaction.options.getBoolean('autoriser');

            // Upsert dans la table PermissionRule
            await prisma.permissionRule.upsert({
                where: {
                    guildId_roleId_command: {
                        guildId: guildId,
                        roleId: role.id,
                        command: cmd
                    }
                },
                update: { allow: allow },
                create: {
                    guildId: guildId,
                    roleId: role.id,
                    command: cmd,
                    allow: allow
                }
            });

            return interaction.reply(`✅ Le rôle **${role.name}** a désormais l'accès **${allow ? 'AUTORISÉ' : 'REFUSÉ'}** à la commande \`/${cmd}\`.`);
        }

        if (sub === 'list') {
            const rules = await prisma.permissionRule.findMany({
                where: { guildId: guildId, allow: true }
            });

            if (rules.length === 0) return interaction.reply("Aucune permission spéciale configurée.");

            const embed = new EmbedBuilder()
                .setTitle('🛡️ Permissions Actives')
                .setColor(0x000000);

            let desc = "";
            rules.forEach(r => {
                desc += `• **/${r.command}** : <@&${r.roleId}>\n`;
            });

            embed.setDescription(desc);
            return interaction.reply({ embeds: [embed] });
        }
    },
};