import { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } from 'discord.js';
import { prisma } from '../../db';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warn')
        .setDescription('Système d\'avertissements')
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
        .addSubcommand(sub => 
            sub.setName('add').setDescription('Donner un avertissement')
               .addUserOption(op => op.setName('target').setDescription('Membre').setRequired(true))
               .addStringOption(op => op.setName('reason').setDescription('Raison').setRequired(true)))
        .addSubcommand(sub => 
            sub.setName('list').setDescription('Voir le casier d\'un membre')
               .addUserOption(op => op.setName('target').setDescription('Membre').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();
        const targetUser = interaction.options.getUser('target');
        
        // On s'assure que l'user existe en BDD
        // (En prod, tu devrais probablement faire un upsert User ici)
        
        if (sub === 'add') {
            const reason = interaction.options.getString('reason');
            
            await prisma.warning.create({
                data: {
                    userId: targetUser.id,
                    staffId: interaction.user.id,
                    reason: reason
                }
            });

            return interaction.reply(`⚠️ **${targetUser.tag}** a reçu un avertissement.\nRaison : ${reason}`);
        }

        if (sub === 'list') {
            const warns = await prisma.warning.findMany({
                where: { userId: targetUser.id },
                orderBy: { createdAt: 'desc' },
                take: 10
            });

            if (warns.length === 0) {
                return interaction.reply(`✅ Le casier de **${targetUser.tag}** est vide.`);
            }

            const embed = new EmbedBuilder()
                .setTitle(`📂 Casier Judiciaire : ${targetUser.tag}`)
                .setColor(0xFFA500);

            let desc = "";
            warns.forEach((w, i) => {
                desc += `**#${i+1}** - ${w.reason} (par <@${w.staffId}>)\n📅 ${w.createdAt.toLocaleDateString()}\n\n`;
            });

            embed.setDescription(desc);
            return interaction.reply({ embeds: [embed] });
        }
    },
};