import { SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mod')
        .setDescription('Outils de modération (Ban, Kick, Mute, Unban)')
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers) // Sécurité Discord native
        // 1. BAN
        .addSubcommand(sub => 
            sub.setName('ban').setDescription('Bannir un membre')
               .addUserOption(op => op.setName('target').setDescription('Membre').setRequired(true))
               .addStringOption(op => op.setName('reason').setDescription('Raison')))
        // 2. KICK
        .addSubcommand(sub => 
            sub.setName('kick').setDescription('Expulser un membre')
               .addUserOption(op => op.setName('target').setDescription('Membre').setRequired(true))
               .addStringOption(op => op.setName('reason').setDescription('Raison')))
        // 3. TIMEOUT (MUTE)
        .addSubcommand(sub => 
            sub.setName('timeout').setDescription('Mute temporaire')
               .addUserOption(op => op.setName('target').setDescription('Membre').setRequired(true))
               .addIntegerOption(op => op.setName('minutes').setDescription('Durée en minutes').setRequired(true)))
        // 4. UNTIMEOUT (UNMUTE) - AJOUTÉ
        .addSubcommand(sub => 
            sub.setName('untimeout').setDescription('Rendre la parole (Unmute)')
               .addUserOption(op => op.setName('target').setDescription('Membre').setRequired(true)))
        // 5. UNBAN - AJOUTÉ
        .addSubcommand(sub => 
            sub.setName('unban').setDescription('Débannir un ID')
               .addStringOption(op => op.setName('id').setDescription('ID Discord de l\'utilisateur').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();
        const reason = interaction.options.getString('reason') || 'Aucune raison';

        try {
            // --- CAS SPÉCIAL : UNBAN (Pas besoin de l'objet Member) ---
            if (sub === 'unban') {
                const id = interaction.options.getString('id');
                // On tente de débannir via l'ID
                await interaction.guild.members.unban(id);
                return interaction.reply(`🕊️ L'utilisateur (ID: ${id}) a été **débanni**.`);
            }

            // --- CAS GÉNÉRAUX : On a besoin du Membre cible ---
            const target = interaction.options.getMember('target');
            
            // Vérification si le membre est sur le serveur
            if (!target) {
                return interaction.reply({ content: "Membre introuvable ou n'est plus sur le serveur.", ephemeral: true });
            }

            // Vérification Hiérarchie (Sauf pour untimeout qui est moins risqué)
            if (!target.bannable && sub !== 'untimeout') {
                return interaction.reply({ content: "❌ Je ne peux pas sanctionner ce membre (grade supérieur ou égal au mien).", ephemeral: true });
            }

            // --- LOGIQUE BAN ---
            if (sub === 'ban') {
                await target.ban({ reason });
                return interaction.reply(`🔨 **${target.user.tag}** a été banni.\nRaison : ${reason}`);
            }

            // --- LOGIQUE KICK ---
            if (sub === 'kick') {
                await target.kick(reason);
                return interaction.reply(`🦶 **${target.user.tag}** a été expulsé.\nRaison : ${reason}`);
            }

            // --- LOGIQUE TIMEOUT ---
            if (sub === 'timeout') {
                const minutes = interaction.options.getInteger('minutes');
                await target.timeout(minutes * 60 * 1000, reason);
                return interaction.reply(`🤐 **${target.user.tag}** a été mute pour ${minutes} minutes.`);
            }

            // --- LOGIQUE UNTIMEOUT ---
            if (sub === 'untimeout') {
                await target.timeout(null); // Null retire le timeout
                return interaction.reply(`🗣️ **${target.user.tag}** a retrouvé la parole.`);
            }

        } catch (error) {
            console.error(error);
            // Gestion d'erreurs fréquentes
            if (String(error).includes('Unknown Ban')) {
                return interaction.reply({ content: "❌ Cet utilisateur n'est pas banni.", ephemeral: true });
            }
            return interaction.reply({ content: "❌ Une erreur est survenue (Vérifiez les permissions du bot).", ephemeral: true });
        }
    },
};