import { SlashCommandBuilder, PermissionFlagsBits, ChannelType } from 'discord.js';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('security')
        .setDescription('Commandes de sécurité du serveur')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
        .addSubcommand(sub => 
            sub.setName('clear').setDescription('Supprimer des messages')
               .addIntegerOption(op => op.setName('nombre').setDescription('Nombre (1-100)').setRequired(true)))
        .addSubcommand(sub => sub.setName('lock').setDescription('Verrouiller le salon actuel'))
        .addSubcommand(sub => sub.setName('unlock').setDescription('Déverrouiller le salon actuel'))
        .addSubcommand(sub => 
            sub.setName('antiraid').setDescription('Activer/Désactiver le mode anti-raid')
               .addBooleanOption(op => op.setName('etat').setDescription('ON ou OFF').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();
        const channel = interaction.channel;

        if (sub === 'clear') {
            const amount = interaction.options.getInteger('nombre');
            if (amount > 100 || amount < 1) return interaction.reply({content: "Entre 1 et 100 max.", ephemeral:true});
            
            await channel.bulkDelete(amount, true); // true = ne pas crash sur les vieux messages
            return interaction.reply({ content: `🧹 ${amount} messages supprimés.`, ephemeral: true });
        }

        if (sub === 'lock') {
            await channel.permissionOverwrites.edit(interaction.guild.id, { SendMessages: false });
            return interaction.reply("🔒 **Salon verrouillé.**");
        }

        if (sub === 'unlock') {
            await channel.permissionOverwrites.edit(interaction.guild.id, { SendMessages: true });
            return interaction.reply("🔓 **Salon déverrouillé.**");
        }

        if (sub === 'antiraid') {
            const etat = interaction.options.getBoolean('etat');
            // Exemple simple : on change le niveau de vérification du serveur
            // En prod, tu pourrais lock tous les salons
            if (etat) {
                // await interaction.guild.setVerificationLevel(4); // Très élevé
                return interaction.reply("🚨 **MODE ANTI-RAID ACTIVÉ !** Sécurité maximale enclenchée.");
            } else {
                return interaction.reply("✅ Mode Anti-Raid désactivé.");
            }
        }
    },
};