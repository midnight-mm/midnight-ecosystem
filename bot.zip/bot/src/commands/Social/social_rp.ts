import { SlashCommandBuilder, EmbedBuilder } from 'discord.js';

module.exports = {
    data: new SlashCommandBuilder()
        .setName('social')
        .setDescription('Réseaux sociaux RP')
        .addSubcommand(sub => 
            sub.setName('twitter').setDescription('Poster un Tweet')
               .addStringOption(op => op.setName('message').setDescription('Contenu').setRequired(true))
               .addAttachmentOption(op => op.setName('image').setDescription('Image (optionnel)')))
        .addSubcommand(sub => 
            sub.setName('insta').setDescription('Poster sur Insta')
               .addAttachmentOption(op => op.setName('photo').setDescription('Photo').setRequired(true))
               .addStringOption(op => op.setName('desc').setDescription('Description')))
        .addSubcommand(sub => sub.setName('tinder').setDescription('Créer/Voir profil Tinder'))
        .addSubcommand(sub => 
            sub.setName('marry').setDescription('Demander en mariage')
               .addUserOption(op => op.setName('love').setDescription('L\'élu(e)').setRequired(true))),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();
        const user = interaction.user;

        // --- TWITTER ---
        if (sub === 'twitter') {
            const msg = interaction.options.getString('message');
            const img = interaction.options.getAttachment('image');

            const embed = new EmbedBuilder()
                .setColor(0x1DA1F2) // Bleu Twitter
                .setAuthor({ name: `@${user.username}`, iconURL: user.displayAvatarURL() })
                .setDescription(msg)
                .setFooter({ text: 'Twitter for iPhone • À l\'instant' });

            if (img) embed.setImage(img.url);

            return interaction.reply({ embeds: [embed] });
        }

        // --- INSTAGRAM ---
        if (sub === 'insta') {
            const photo = interaction.options.getAttachment('photo');
            const desc = interaction.options.getString('desc') || '';

            const embed = new EmbedBuilder()
                .setColor(0xC13584) // Dégradé Insta (Rose)
                .setAuthor({ name: user.username, iconURL: user.displayAvatarURL() })
                .setImage(photo.url)
                .setDescription(`**${user.username}** ${desc}`)
                .setFooter({ text: '❤️ 1,234 J\'aime' });

            return interaction.reply({ embeds: [embed] });
        }

        // --- TINDER ---
        if (sub === 'tinder') {
            return interaction.reply({ 
                content: `🔥 **Profil Tinder de ${user.username}**\n\n📜 Bio : "Cherche complice pour braquage."\n📍 Distance : 2km\n\n[❌ Nope] [⭐ Super Like] [💚 Like]`, 
                ephemeral: true 
            });
        }

        // --- MARRY ---
        if (sub === 'marry') {
            const love = interaction.options.getUser('love');
            if (love.id === user.id) return interaction.reply("💔 Tu ne peux pas t'épouser toi-même.");

            return interaction.reply(`💍 **${love}, acceptes-tu d'épouser ${user} ?**\n*(Répondez par Oui pour valider)*`);
        }
    },
};