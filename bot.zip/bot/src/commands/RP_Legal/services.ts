import { SlashCommandBuilder, EmbedBuilder, ChannelType } from 'discord.js';

// Petite mémoire temporaire pour les prises de service (reset au redémarrage du bot)
const serviceMap = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('service')
        .setDescription('Gestion du service et des métiers')
        // PRIS DE SERVICE
        .addSubcommand(sub => sub.setName('prise').setDescription('Prendre son service'))
        .addSubcommand(sub => sub.setName('fin').setDescription('Finir son service'))
        // DISPATCH
        .addSubcommand(sub => 
            sub.setName('dispatch').setDescription('Envoyer une alerte')
               .addStringOption(op => op.setName('message').setDescription('Message').setRequired(true)))
        // EMS REVIVE
        .addSubcommand(sub => 
            sub.setName('revive').setDescription('(EMS) Enregistrer un soin')
               .addStringOption(op => op.setName('id').setDescription('ID du joueur soigné').setRequired(true)))
        // JUSTICE
        .addSubcommand(sub => sub.setName('justice').setDescription('(Juge) Accéder au casier')),

    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();
        const user = interaction.user;

        // --- PRISE DE SERVICE ---
        if (sub === 'prise') {
            serviceMap.set(user.id, new Date());
            return interaction.reply(`👮 **${user.username}** a pris son service à ${new Date().toLocaleTimeString()}.`);
        }

        // --- FIN DE SERVICE ---
        if (sub === 'fin') {
            const startTime = serviceMap.get(user.id);
            if (!startTime) return interaction.reply({ content: "❌ Vous n'avez pas pris votre service.", ephemeral: true });

            const endTime = new Date();
            const duration = (endTime.getTime() - startTime.getTime()) / 1000 / 60; // en minutes
            serviceMap.delete(user.id);

            return interaction.reply(`🛑 **Fin de service.** Durée : **${Math.floor(duration)} minutes**. (Sauvegardé)`);
        }

        // --- DISPATCH ---
        if (sub === 'dispatch') {
            const msg = interaction.options.getString('message');
            const embed = new EmbedBuilder()
                .setTitle('📢 DISPATCH CENTRAL')
                .setDescription(msg)
                .setColor(0xE74C3C) // Rouge urgence
                .setFooter({ text: `Émis par : ${user.username}` });
            
            // Idéalement, envoie ça dans un salon spécifique configuré en DB
            return interaction.reply({ embeds: [embed] });
        }

        // --- EMS REVIVE ---
        if (sub === 'revive') {
            const idJoueur = interaction.options.getString('id');
            // Logique de facturation ici...
            return interaction.reply(`🚑 **Rapport EMS :** Citoyen (ID: ${idJoueur}) réanimé par ${user.username}. Facture envoyée.`);
        }

        // --- JUSTICE ---
        if (sub === 'justice') {
            return interaction.reply({ content: "⚖️ **Système Justice :** Veuillez utiliser le MDT (`/mdt search`) pour modifier le casier.", ephemeral: true });
        }
    },
};