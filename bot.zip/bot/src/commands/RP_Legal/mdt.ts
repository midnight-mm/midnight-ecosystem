import { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { prisma } from '../../db'; // Import de la DB pour les futures perms

module.exports = {
    // 1. La propriété 'data' est OBLIGATOIRE
    data: new SlashCommandBuilder()
        .setName('mdt')
        .setDescription('Outils Police (Mobile Data Terminal)')
        .addSubcommand(sub => 
            sub.setName('search').setDescription('Rechercher un citoyen')
               .addStringOption(opt => opt.setName('nom').setDescription('Nom du suspect').setRequired(true))
        )
        .addSubcommand(sub => 
            sub.setName('plate').setDescription('Rechercher une plaque')
               .addStringOption(opt => opt.setName('numero').setDescription('Numéro de plaque').setRequired(true))
        ),

    // 2. La propriété 'execute' est OBLIGATOIRE
    async execute(interaction: any) {
        const sub = interaction.options.getSubcommand();

        // --- VÉRIFICATION PERMISSIONS (INTEGRATION BLOC 5) ---
        // Décommentez ce bloc pour activer la vérification des rôles via /perms set
        /*
        const userRoles = interaction.member.roles.cache.map((r: any) => r.id);
        const permission = await prisma.permissionRule.findFirst({
            where: {
                guildId: interaction.guild.id,
                command: 'mdt',
                roleId: { in: userRoles },
                allow: true
            }
        });

        // Si aucune permission n'est trouvée et que l'utilisateur n'est pas Admin
        if (!permission && !interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: "⛔ Accès refusé. Vous n'avez pas le rôle requis (Police/Légal).", ephemeral: true });
        }
        */

        if (sub === 'search') {
            const nom = interaction.options.getString('nom');
            
            // Simulation de réponse
            const embed = new EmbedBuilder()
                .setTitle(`👮 Dossier Criminel : ${nom}`)
                .setColor(0x0000FF)
                .addFields(
                    { name: 'Casier', value: 'Vierge', inline: true },
                    { name: 'Permis', value: 'Valide', inline: true },
                    { name: 'Véhicules', value: 'Aucun', inline: true }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        }

        if (sub === 'plate') {
            const plaque = interaction.options.getString('numero');
            await interaction.reply(`🚗 Recherche véhicule plaque **${plaque}**... (Simulation: Propriétaire Inconnu)`);
        }
    },
};